
import React, { useState, useEffect } from 'react';
import { ProjectBrief, BuildingType } from '../types';

interface Props {
  data: ProjectBrief | null;
  onSave: (data: ProjectBrief) => void;
}

const ProjectBriefForm: React.FC<Props> = ({ data, onSave }) => {
  const [isLocked, setIsLocked] = useState(!!data);
  const [formData, setFormData] = useState<Partial<ProjectBrief>>(data || {
    unit: 'sqft',
    buildingType: 'Commercial',
    occupancyDensity: 10,
    occupancyType: '',
    operatingHours: '10:00 - 19:00',
    performanceExpectations: 'High efficiency design target',
    targetTimeline: 'Q4 2025',
    builtUpArea: 0,
    floors: 1,
    targetBudget: 0
  });

  useEffect(() => {
    if (data) {
      setFormData(data);
      setIsLocked(true);
    }
  }, [data]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const required: (keyof ProjectBrief)[] = [
      'clientName', 
      'siteAddress', 
      'city', 
      'buildingType', 
      'occupancyType', 
      'operatingHours', 
      'targetTimeline', 
      'contractorName', 
      'performanceExpectations'
    ];

    const missing = required.filter(f => !formData[f] || String(formData[f]).trim() === '');
    
    if (!formData.builtUpArea || formData.builtUpArea <= 0) missing.push('builtUpArea');
    if (!formData.targetBudget || formData.targetBudget <= 0) missing.push('targetBudget');
    if (!formData.floors || formData.floors <= 0) missing.push('floors');
    if (!formData.occupancyDensity || formData.occupancyDensity <= 0) missing.push('occupancyDensity');

    if (missing.length > 0) {
      alert(`MIS Intake Blocked: Please complete these mandatory consultancy fields: ${missing.join(', ')}`);
      return;
    }

    onSave(formData as ProjectBrief);
    setIsLocked(true);
  };

  if (isLocked && data) {
    return (
      <div className="apple-card p-12 animate-fadeIn max-w-3xl mx-auto border-t-4 border-t-[#0066CC]">
        <div className="flex justify-between items-start mb-10">
          <div>
            <h2 className="text-3xl font-extrabold tracking-tight text-black">{data.clientName}</h2>
            <p className="text-lg text-[#86868B] font-medium mt-1">{data.city}, {data.siteAddress}</p>
          </div>
          <button 
            onClick={() => setIsLocked(false)}
            className="text-sm font-semibold text-[#0066CC] hover:underline px-4 py-2 bg-[#F5F5F7] rounded-full transition-colors"
          >
            Edit Project Brief
          </button>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 gap-y-10 gap-x-12">
          {[
            { label: 'Asset Class', value: data.buildingType },
            { label: 'Usage Context', value: data.occupancyType },
            { label: 'Built-up Area', value: `${data.builtUpArea.toLocaleString()} ${data.unit}` },
            { label: 'Verticality', value: `${data.floors} Floors` },
            { label: 'Density', value: `${data.occupancyDensity} sqft/P` },
            { label: 'Operating Shift', value: data.operatingHours },
            { label: 'CAPEX Ceiling', value: `₹${data.targetBudget.toLocaleString('en-IN')}` },
            { label: 'Target Window', value: data.targetTimeline },
            { label: 'MEP Partner', value: data.contractorName },
          ].map((item, i) => (
            <div key={i} className="animate-fadeIn" style={{ animationDelay: `${i * 0.05}s` }}>
              <p className="text-[11px] font-bold text-[#86868B] uppercase tracking-widest mb-1.5">{item.label}</p>
              <p className="text-base font-semibold text-black tracking-tight">{item.value}</p>
            </div>
          ))}
          <div className="col-span-full pt-8 border-t border-[#F5F5F7]">
            <p className="text-[11px] font-bold text-[#86868B] uppercase tracking-widest mb-3">Performance Directives</p>
            <p className="text-sm text-[#424245] leading-relaxed italic font-medium bg-[#FBFBFD] p-4 rounded-xl border border-[#D2D2D7]/30">
              "{data.performanceExpectations}"
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="apple-card p-12 space-y-12 animate-fadeIn max-w-4xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-10 gap-y-10">
        <div className="lg:col-span-2">
          <label className="block text-sm font-semibold text-black mb-2.5">Project / Client Entity Name</label>
          <input 
            type="text" required placeholder="Legal corporate name"
            className="w-full apple-input font-medium"
            value={formData.clientName || ''}
            onChange={e => setFormData({...formData, clientName: e.target.value})}
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-black mb-2.5">Building Category</label>
          <select 
            className="w-full apple-input appearance-none bg-no-repeat bg-right-4 font-medium"
            value={formData.buildingType}
            onChange={e => setFormData({...formData, buildingType: e.target.value as BuildingType})}
          >
            <option value="Residential">Residential</option>
            <option value="Commercial">Commercial</option>
            <option value="Industrial">Industrial</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-semibold text-black mb-2.5">Site Geography (City)</label>
          <input 
            type="text" required placeholder="e.g. Mumbai"
            className="w-full apple-input font-medium"
            value={formData.city || ''}
            onChange={e => setFormData({...formData, city: e.target.value})}
          />
        </div>

        <div className="lg:col-span-2">
          <label className="block text-sm font-semibold text-black mb-2.5">Specific Site Address</label>
          <input 
            type="text" required placeholder="Full site location"
            className="w-full apple-input font-medium"
            value={formData.siteAddress || ''}
            onChange={e => setFormData({...formData, siteAddress: e.target.value})}
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-black mb-2.5">Built-up Area (Sq Ft)</label>
          <input 
            type="number" required placeholder="0"
            className="w-full apple-input font-bold text-[#0066CC]"
            value={formData.builtUpArea || ''}
            onChange={e => setFormData({...formData, builtUpArea: Number(e.target.value)})}
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-black mb-2.5">Occupancy Type</label>
          <input 
            type="text" required placeholder="e.g. Server Room, IT Park"
            className="w-full apple-input font-medium"
            value={formData.occupancyType || ''}
            onChange={e => setFormData({...formData, occupancyType: e.target.value})}
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-black mb-2.5">Density (Sqft per Person)</label>
          <input 
            type="number" required placeholder="10"
            className="w-full apple-input font-medium"
            value={formData.occupancyDensity || ''}
            onChange={e => setFormData({...formData, occupancyDensity: Number(e.target.value)})}
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-black mb-2.5">Vertical Storeys (F)</label>
          <input 
            type="number" required placeholder="1"
            className="w-full apple-input font-medium"
            value={formData.floors || ''}
            onChange={e => setFormData({...formData, floors: Number(e.target.value)})}
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-black mb-2.5">Operating Hours</label>
          <input 
            type="text" required placeholder="e.g. 24x7"
            className="w-full apple-input font-medium"
            value={formData.operatingHours || ''}
            onChange={e => setFormData({...formData, operatingHours: e.target.value})}
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-black mb-2.5">Target Budget (INR)</label>
          <input 
            type="number" required placeholder="0"
            className="w-full apple-input font-bold text-[#34C759]"
            value={formData.targetBudget || ''}
            onChange={e => setFormData({...formData, targetBudget: Number(e.target.value)})}
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-black mb-2.5">Completion Deadline</label>
          <input 
            type="text" required placeholder="e.g. Q1 2026"
            className="w-full apple-input font-medium"
            value={formData.targetTimeline || ''}
            onChange={e => setFormData({...formData, targetTimeline: e.target.value})}
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-black mb-2.5">MEP Execution Lead</label>
          <input 
            type="text" required placeholder="Contractor name"
            className="w-full apple-input font-medium"
            value={formData.contractorName || ''}
            onChange={e => setFormData({...formData, contractorName: e.target.value})}
          />
        </div>

        <div className="md:col-span-2 lg:col-span-3">
          <label className="block text-sm font-semibold text-black mb-2.5">Technical & Performance Directives</label>
          <textarea 
            required rows={4}
            placeholder="Specify filtration norms, noise levels, and efficiency benchmarks..."
            className="w-full apple-input resize-none font-medium leading-relaxed"
            value={formData.performanceExpectations || ''}
            onChange={e => setFormData({...formData, performanceExpectations: e.target.value})}
          />
        </div>
      </div>

      <div className="flex justify-center pt-12 border-t border-[#F5F5F7]">
        <button type="submit" className="apple-btn-primary px-16 py-4 text-lg shadow-xl shadow-[#0066CC]/20 active:scale-95 transition-transform">
          Lock & Commit Strategic Brief
        </button>
      </div>
    </form>
  );
};

export default ProjectBriefForm;
