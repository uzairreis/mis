
import React from 'react';
import { ProjectState, LeakCategory } from '../types';
import { analyzeProjectData } from '../services/geminiService';

interface Props {
  state: ProjectState;
}

const ConsultancyReport: React.FC<Props> = ({ state }) => {
  const [analysis, setAnalysis] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const runAnalysis = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await analyzeProjectData(state);
      if (result.error) setError(result.error);
      else setAnalysis(result);
    } catch (err: any) {
      setError("Analysis system unavailable.");
    } finally {
      setLoading(false);
    }
  };

  const totalCost = state.inventory.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
  const totalTR = state.inventory.reduce((sum, item) => {
    const cat = item.category.toLowerCase();
    if (cat.includes('chiller') || cat.includes('vrf')) return sum + (item.capacity * item.quantity);
    return sum;
  }, 0);

  if (!state.brief || state.inventory.length === 0) {
    return (
      <div className="apple-card p-12 text-center bg-[#FBFBFD]">
        <h3 className="text-xl font-bold tracking-tight">Report Blocked</h3>
        <p className="text-sm text-[#86868B] mt-2">Please complete the mandatory baseline and inventory logs first.</p>
      </div>
    );
  }

  return (
    <div className="space-y-16 animate-fadeIn pb-24">
      {/* Financial Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { label: 'Estimated Total', value: `₹${totalCost.toLocaleString('en-IN')}`, color: 'text-black' },
          { label: 'Cost per TR', value: `₹${totalTR > 0 ? Math.round(totalCost / totalTR).toLocaleString('en-IN') : 'N/A'}`, color: 'text-[#86868B]' },
          { label: 'Cost per Sqft', value: `₹${Math.round(totalCost / state.brief.builtUpArea).toLocaleString('en-IN')}`, color: 'text-[#86868B]' },
          { label: 'Total Load', value: `${totalTR} TR`, color: 'text-black' },
        ].map((stat, i) => (
          <div key={i} className="apple-card p-6 flex flex-col justify-between h-32 shadow-none border-[#D2D2D7]/40">
            <p className="text-[11px] font-bold text-[#86868B] uppercase tracking-widest">{stat.label}</p>
            <p className={`text-2xl font-extrabold tracking-tight ${stat.color}`}>{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="flex justify-center">
        <button 
          onClick={runAnalysis}
          disabled={loading}
          className="apple-btn-primary px-16 py-5 text-xl flex items-center gap-4"
        >
          {loading && <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>}
          {loading ? 'Synthesizing...' : 'Run Strategic Analysis'}
        </button>
      </div>

      {analysis && (
        <div className="space-y-12 animate-fadeIn">
          {/* Executive Summary */}
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-extrabold tracking-tight mb-6">Strategic Summary</h2>
            <p className="text-lg text-[#424245] leading-relaxed font-medium">{analysis.executiveSummary}</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            {/* Leaks */}
            <div className="space-y-6">
              <h3 className="text-xl font-bold tracking-tight px-2 flex items-center gap-3">
                <span className="text-[#FF3B30]">●</span>
                Resource Leaks
              </h3>
              <div className="space-y-4">
                {analysis.leaks.map((leak: any, idx: number) => (
                  <div key={idx} className="apple-card p-6 border-l-4 border-l-[#FF3B30]">
                    <div className="flex justify-between mb-2">
                      <span className="text-[10px] font-bold text-[#86868B] uppercase tracking-widest">{leak.category}</span>
                      <span className="font-bold text-[#FF3B30]">-₹{leak.impactAmount.toLocaleString('en-IN')}</span>
                    </div>
                    <p className="font-bold text-lg tracking-tight mb-2">{leak.description}</p>
                    <p className="text-sm text-[#86868B] leading-relaxed italic">{leak.justification}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Suggestions */}
            <div className="space-y-6">
              <h3 className="text-xl font-bold tracking-tight px-2 flex items-center gap-3">
                <span className="text-[#34C759]">●</span>
                Value Engineering
              </h3>
              <div className="space-y-4">
                {analysis.suggestions.map((s: any, idx: number) => (
                  <div key={idx} className="apple-card p-6 border-l-4 border-l-[#34C759]">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-bold text-lg tracking-tight">{s.title}</h4>
                      <span className="text-[10px] font-bold px-2 py-1 bg-[#F5F5F7] rounded-full text-[#86868B] uppercase">Risk: {s.riskLevel}</span>
                    </div>
                    <p className="text-sm text-[#424245] mb-4">{s.basis}</p>
                    <div className="flex justify-between items-center text-[11px] font-bold uppercase tracking-widest">
                      <span className="text-[#34C759]">Potential +₹{s.costImpact.toLocaleString('en-IN')}</span>
                      <span className="text-[#86868B]">{s.complianceImpact}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="pt-20 text-center text-[11px] font-bold text-[#D2D2D7] uppercase tracking-[0.4em]">
            Validated MIS Output • {new Date().toLocaleDateString()}
          </div>
        </div>
      )}
    </div>
  );
};

export default ConsultancyReport;
