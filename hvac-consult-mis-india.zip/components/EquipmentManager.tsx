
import React from 'react';
import { Equipment } from '../types';

interface Props {
  items: Equipment[];
  onAdd: (item: Equipment) => void;
  onRemove: (id: string) => void;
}

const EquipmentManager: React.FC<Props> = ({ items, onAdd, onRemove }) => {
  const [showForm, setShowForm] = React.useState(false);
  const [newItem, setNewItem] = React.useState<Partial<Equipment>>({
    category: 'Chiller',
    origin: 'Local',
    efficiencyType: 'COP',
    capacityUnit: 'TR'
  });

  const handleAdd = () => {
    if (!newItem.category || !newItem.unitPrice || !newItem.quantity) {
      alert("Please fill required fields.");
      return;
    }
    onAdd({
      ...newItem as Equipment,
      id: Math.random().toString(36).substr(2, 9)
    });
    setShowForm(false);
    setNewItem({ category: 'Chiller', origin: 'Local', efficiencyType: 'COP', capacityUnit: 'TR' });
  };

  return (
    <div className="apple-card p-10">
      <div className="flex justify-between items-center mb-10 pb-6 border-b border-[#F5F5F7]">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Equipment Inventory</h2>
          <p className="text-sm text-[#86868B] mt-1">Detailed HVAC material specification log.</p>
        </div>
        <button 
          onClick={() => setShowForm(!showForm)}
          className="apple-btn-primary px-6 py-2 text-sm"
        >
          {showForm ? 'Cancel' : 'Add Item'}
        </button>
      </div>

      {showForm && (
        <div className="bg-[#FBFBFD] p-8 rounded-2xl border border-[#D2D2D7] mb-10 space-y-6 animate-fadeIn">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="text-[11px] font-bold text-[#86868B] uppercase tracking-widest mb-2 block">Category</label>
              <select className="w-full apple-input" value={newItem.category} onChange={e => setNewItem({...newItem, category: e.target.value})}>
                <option>Chiller</option>
                <option>VRF System</option>
                <option>AHU</option>
                <option>Cooling Tower</option>
                <option>Pump</option>
                <option>Ducting</option>
                <option>Insulation</option>
              </select>
            </div>
            <div>
              <label className="text-[11px] font-bold text-[#86868B] uppercase tracking-widest mb-2 block">Spec / Capacity</label>
              <div className="flex gap-2">
                <input type="number" className="apple-input flex-1" placeholder="Val" onChange={e => setNewItem({...newItem, capacity: Number(e.target.value)})} />
                <input type="text" className="apple-input w-24" placeholder="TR" value={newItem.capacityUnit} onChange={e => setNewItem({...newItem, capacityUnit: e.target.value})} />
              </div>
            </div>
            <div>
              <label className="text-[11px] font-bold text-[#86868B] uppercase tracking-widest mb-2 block">Quantity</label>
              <input type="number" className="w-full apple-input" onChange={e => setNewItem({...newItem, quantity: Number(e.target.value)})} />
            </div>
            <div>
              <label className="text-[11px] font-bold text-[#86868B] uppercase tracking-widest mb-2 block">Unit Price (INR)</label>
              <input type="number" className="w-full apple-input" onChange={e => setNewItem({...newItem, unitPrice: Number(e.target.value)})} />
            </div>
            <div>
              <label className="text-[11px] font-bold text-[#86868B] uppercase tracking-widest mb-2 block">Efficiency ({newItem.efficiencyType})</label>
              <input type="number" step="0.01" className="w-full apple-input" onChange={e => setNewItem({...newItem, efficiencyValue: Number(e.target.value)})} />
            </div>
            <div>
              <label className="text-[11px] font-bold text-[#86868B] uppercase tracking-widest mb-2 block">Supplier</label>
              <input type="text" className="w-full apple-input" onChange={e => setNewItem({...newItem, supplier: e.target.value})} />
            </div>
          </div>
          <div className="flex justify-end pt-4">
            <button onClick={handleAdd} className="apple-btn-secondary px-8 py-2">Confirm Addition</button>
          </div>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="text-[11px] font-bold text-[#86868B] uppercase tracking-widest border-b border-[#F5F5F7]">
              <th className="py-4 pr-4">Category</th>
              <th className="py-4 pr-4">Specification</th>
              <th className="py-4 pr-4 text-center">Qty</th>
              <th className="py-4 pr-4 text-right">Unit Price</th>
              <th className="py-4 pr-4 text-right">Total</th>
              <th className="py-4 text-right"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#F5F5F7]">
            {items.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-12 text-center text-[#86868B] font-medium italic">Inventory is currently empty.</td>
              </tr>
            ) : items.map(item => (
              <tr key={item.id} className="text-sm font-medium hover:bg-[#FBFBFD] transition-colors group">
                <td className="py-5 pr-4 font-bold">{item.category}</td>
                <td className="py-5 pr-4 text-[#424245]">{item.capacity} {item.capacityUnit} • {item.supplier}</td>
                <td className="py-5 pr-4 text-center">{item.quantity}</td>
                <td className="py-5 pr-4 text-right">₹{item.unitPrice.toLocaleString('en-IN')}</td>
                <td className="py-5 pr-4 text-right font-bold">₹{(item.quantity * item.unitPrice).toLocaleString('en-IN')}</td>
                <td className="py-5 text-right">
                  <button onClick={() => onRemove(item.id)} className="text-[#FF3B30] opacity-0 group-hover:opacity-100 transition-opacity">Remove</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default EquipmentManager;
