
import React from 'react';
import { ComplianceStatus } from '../types';

interface Props {
  data: ComplianceStatus | null;
  onSave: (data: ComplianceStatus) => void;
}

const ComplianceTracker: React.FC<Props> = ({ data, onSave }) => {
  const [formData, setFormData] = React.useState<ComplianceStatus>(data || {
    nbcCompliant: false,
    ecbcCompliant: false,
    fireNocStatus: 'Pending',
    moefClearance: false,
    refrigerantType: '',
    municipalApproval: ''
  });

  return (
    <div className="apple-card p-10 mt-8">
      <h2 className="text-xl font-bold tracking-tight mb-8">Compliance Matrix</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        <div className="space-y-6">
          <label className="flex items-center justify-between p-4 bg-[#FBFBFD] rounded-xl cursor-pointer hover:bg-[#F5F5F7] transition-colors">
            <span className="text-sm font-semibold">NBC Fire & Ventilation</span>
            <input 
              type="checkbox" 
              className="w-5 h-5 accent-[#0066CC]"
              checked={formData.nbcCompliant}
              onChange={e => setFormData({...formData, nbcCompliant: e.target.checked})}
            />
          </label>
          <label className="flex items-center justify-between p-4 bg-[#FBFBFD] rounded-xl cursor-pointer hover:bg-[#F5F5F7] transition-colors">
            <span className="text-sm font-semibold">ECBC Energy Code</span>
            <input 
              type="checkbox" 
              className="w-5 h-5 accent-[#0066CC]"
              checked={formData.ecbcCompliant}
              onChange={e => setFormData({...formData, ecbcCompliant: e.target.checked})}
            />
          </label>
        </div>

        <div className="space-y-6">
          <div>
            <label className="text-[11px] font-bold text-[#86868B] uppercase tracking-widest mb-2 block">Fire NOC</label>
            <select 
              className="w-full apple-input text-sm"
              value={formData.fireNocStatus}
              onChange={e => setFormData({...formData, fireNocStatus: e.target.value as any})}
            >
              <option value="Pending">Pending</option>
              <option value="Applied">Applied</option>
              <option value="Received">Received</option>
              <option value="Not Required">Not Required</option>
            </select>
          </div>
          <div>
            <label className="text-[11px] font-bold text-[#86868B] uppercase tracking-widest mb-2 block">Municipal Approvals</label>
            <input 
              type="text" 
              className="w-full apple-input text-sm"
              placeholder="Approval Status"
              value={formData.municipalApproval}
              onChange={e => setFormData({...formData, municipalApproval: e.target.value})}
            />
          </div>
        </div>
      </div>
      <div className="mt-10 flex justify-end">
        <button onClick={() => onSave(formData)} className="apple-btn-secondary px-8 py-2">Update Matrix</button>
      </div>
    </div>
  );
};

export default ComplianceTracker;
