
import { GoogleGenAI, Type } from "@google/genai";
import { ProjectState, LeakCategory } from "../types";

export async function analyzeProjectData(state: ProjectState) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  if (!state.brief || !state.design || state.inventory.length === 0) {
    return { error: "Insufficient data for detailed consultancy analysis. Ensure Brief, Design Loads, and BOQ are complete." };
  }

  const prompt = `
    Act as a Senior HVAC Consultant for an Indian project. Analyze the following project data for Cash Leaks and Value Engineering.
    
    Project Brief: ${JSON.stringify(state.brief)}
    Design Inputs: ${JSON.stringify(state.design)}
    Equipment Inventory: ${JSON.stringify(state.inventory)}
    Compliance Status: ${JSON.stringify(state.compliance)}

    Identify specific cash leaks based on:
    1. Over-sizing (Equipment capacity vs design load).
    2. Pricing inconsistencies (Supplier variance).
    3. Import vs Local selection.
    4. Energy efficiency ROI (Low COP for high CAPEX).

    Rules:
    - Categorize leaks into: ${Object.values(LeakCategory).join(", ")}.
    - Provide 3-5 specific Value Engineering suggestions with Risk Assessment.
    - Check compliance against India's NBC and ECBC based on provided status.
    - DO NOT hallucinate benchmarks; use the entered pricing logic.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview", // Use flash for faster inference in MIS systems
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["leaks", "suggestions", "executiveSummary"],
          properties: {
            leaks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                required: ["category", "description", "impactAmount", "justification"],
                properties: {
                  category: { type: Type.STRING },
                  description: { type: Type.STRING },
                  impactAmount: { type: Type.NUMBER },
                  justification: { type: Type.STRING }
                }
              }
            },
            suggestions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                required: ["title", "basis", "costImpact", "energyImpact", "complianceImpact", "riskLevel"],
                properties: {
                  title: { type: Type.STRING },
                  basis: { type: Type.STRING },
                  costImpact: { type: Type.NUMBER },
                  energyImpact: { type: Type.STRING },
                  complianceImpact: { type: Type.STRING },
                  riskLevel: { type: Type.STRING }
                }
              }
            },
            executiveSummary: { type: Type.STRING }
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("Empty response from AI");
    return JSON.parse(text);
  } catch (error: any) {
    console.error("Gemini Analysis Error:", error);
    return { error: error.message || "Failed to generate consultancy report. The AI service may be temporarily unavailable." };
  }
}
